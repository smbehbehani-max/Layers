# Layers of Kuwait — standalone website

Upload everything in this folder to a GitHub repository and turn on GitHub Pages.
Live location (Go live) works here because the page runs on its own address, outside Claude.

1. github.com → New repository → name it e.g. `layers` → Public → Create.
2. "Add file" → "Upload files" → select all 8 files (index.html, manifest.webmanifest, sw.js, README.md and the 4 .png icons) → Commit.
3. Settings → Pages → Source: "Deploy from a branch" → Branch: main, folder: / (root) → Save.
4. After about a minute the site is at https://YOUR-USERNAME.github.io/layers/
5. On iPhone: open it in Safari → Share → Add to Home Screen. Tap Go live and allow location.

Note: the weekly "What's new" research feed runs on Claude's hosting and does not appear in this copy.
